<?php
require('../controlador/controlador.php');

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">

  <!-- ======= Título/Breadcrumbs ======= -->
  <section class="intro-single">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-8">
          <div class="title-single-box">
            <h1 class="title-single">Socializar nunca ha sido más fácil</h1>
          </div>
        </div>
        <div class="col-md-12 col-lg-4">
          <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="inicio.php">Inicio</a>
              </li>
              <li class="breadcrumb-item active" aria-current="page">
                Conócenos
              </li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section><!-- FIN Título/Breadcrumbs -->

  <!-- ======= Acerca de eVentalia ======= -->
  <section class="section-about">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 position-relative">
          <div class="about-img-box">
            <img src="../assets/img/slide-about-1.jpg" alt="" class="img-fluid">
          </div>
          <div class="sinse-box">
            <h3 class="sinse-title">eVentalia
              <span></span>
              <br> Desde 2023
            </h3>
            <p>Eventos & Sociales</p>
          </div>
        </div>
        <div class="col-md-12 section-t8 position-relative">
          <div class="row">
            <div class="col-md-6 col-lg-5">
              <img src="../assets/img/Conocenos-Razon-de-ser.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-2  d-none d-lg-block position-relative">
              <div class="title-vertical d-flex justify-content-start">
                <span>La razón de ser de eVentalia</span>
              </div>
            </div>
            <div class="col-md-6 col-lg-5 section-md-t3">
              <div class="title-box-d">
                <h3 class="title-d">Los
                  <span class="color-d">eVentos</span> al alcance
                  <br> de todos.
                </h3>
              </div>
              <p class="color-text-a">
              ¡Bienvenido/a a nuestro sitio! Aquí encontrarás una amplia variedad de eventos al alcance de todos.
              Desde conciertos y espectáculos, hasta conferencias y exposiciones, tenemos algo para cada gusto e interés.
              Explora nuestro catálogo y descubre las emocionantes oportunidades que te esperan. ¡No importa tus preferencias
              o presupuesto, estamos comprometidos a hacer que los eventos sean accesibles para todos! Únete a nosotros y sé
              parte de la emoción.
              </p>
              <br/>
              <p class="color-text-a">
                <ol>
                  <li>Explora nuevas pasiones y conecta con personas apasionadas que comparten tus interesesen.</li>
                  <br/>
                  <li>Desde eventos deportivos que te dejarán sin aliento hasta festivales culturales que despertarán tus sentidos, estamos aquí para acercarte a momentos únicos e irrepetibles.</li>
                  <br/>
                  <li>Descubre, vive y disfruta los eventos como nunca antes lo habías hecho. ¡Te esperamos con los brazos abiertos!</li>
                </ol>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- FIN Acerca de eVentalia -->

  <!-- ======= Fundadores de eVentalia ======= -->
  <section class="section-agents section-t8">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a">Fundadores de eVentalia</h2>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="card-box-d">
            <div class="card-img-d">
              <img src="../assets/img/JorgeBueno.jpg" alt="" class="img-d img-fluid">
            </div>
            <div class="card-overlay card-overlay-hover">
              <div class="card-header-d">
                <div class="card-title-d align-self-center">
                  <h3 class="title-d">
                    <a href="#" class="link-two">Jorge Bueno
                  </h3>
                </div>
              </div>
              <div class="card-body-d">
                <p class="content-d color-text-a">
                  "Pero que bien me veo en esta foto ( ͡° ͜ʖ ͡°)".
                </p>
                <div class="info-agents color-a">
                  <p>
                    <strong>Teléfono: </strong> +34 356 945 234
                  </p>
                  <p>
                    <strong>Email: </strong> agents@example.com
                  </p>
                </div>
              </div>
              <div class="card-footer-d">
                <div class="socials-footer d-flex justify-content-center">
                  <ul class="list-inline">
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-facebook" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-twitter" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-instagram" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-linkedin" aria-hidden="true"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box-d">
            <div class="card-img-d">
              <img src="../assets/img/JorgeSalazar.jpg" alt="" class="img-d img-fluid">
            </div>
            <div class="card-overlay card-overlay-hover">
              <div class="card-header-d">
                <div class="card-title-d align-self-center">
                  <h3 class="title-d">
                    <a href="#" class="link-two">Jorge Salazar
                  </h3>
                </div>
              </div>
              <div class="card-body-d">
                <p class="content-d color-text-a">
                  "En que momento me metí en programación (╯ ͠° ͟ʖ ͡°)╯┻━┻".
                </p>
                <div class="info-agents color-a">
                  <p>
                    <strong>Teléfono: </strong> +34 356 945 234
                  </p>
                  <p>
                    <strong>Email: </strong> agents@example.com
                  </p>
                </div>
              </div>
              <div class="card-footer-d">
                <div class="socials-footer d-flex justify-content-center">
                  <ul class="list-inline">
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-facebook" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-twitter" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-instagram" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-linkedin" aria-hidden="true"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box-d">
            <div class="card-img-d">
              <img src="../assets/img/RubenLozano.jpg" alt="" class="img-d img-fluid">
            </div>
            <div class="card-overlay card-overlay-hover">
              <div class="card-header-d">
                <div class="card-title-d align-self-center">
                  <h3 class="title-d">
                    <a href="#" class="link-two">Rubén Lozano
                  </h3>
                </div>
              </div>
              <div class="card-body-d">
                <p class="content-d color-text-a">
                  "A mi no me preguntes que voy cuajado ¯\_(ツ)_/¯".
                </p>
                <div class="info-agents color-a">
                  <p>
                    <strong>Teléfono: </strong> +34 356 945 234
                  </p>
                  <p>
                    <strong>Email: </strong> agents@example.com
                  </p>
                </div>
              </div>
              <div class="card-footer-d">
                <div class="socials-footer d-flex justify-content-center">
                  <ul class="list-inline">
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-facebook" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-twitter" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-instagram" aria-hidden="true"></i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="#" class="link-one">
                        <i class="bi bi-linkedin" aria-hidden="true"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- Fin Fundadores de eVentalia -->

</main>

<?php include('modulos_compartidos/footer.php'); ?>