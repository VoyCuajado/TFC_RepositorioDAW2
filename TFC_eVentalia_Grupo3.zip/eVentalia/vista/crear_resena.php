<?php
require('../controlador/controlador.php');
controlarVistas();

include('../modelo/evento.php');
$evento = new Evento();
$id_ceador = $evento->mostrarEvento($_GET["id_evento"])["ID_CREADOR"];

// Comprobaciones previas
# --------------------------------------------------------------
// Si existe el evento
if (!$id_ceador) {
    echo '<script>alert("¡Oops! Parece que el evento no existe.");</script>';
    echo '<script>window.location.href = "ver_eventos.php?pag=1";</script>';
}

// Si el usuario está subscrito
$usuarioSubscrito = $evento->comporobarSubscripcion($_GET["id_evento"], $datosUsuario["ID_PERSONA"]);
if (!$usuarioSubscrito) {
    echo '<script>alert("¡Solo pueden escribir reseñas los subscriptores!");</script>';
    echo '<script>window.location.href = "ver_eventos.php?pag=1";</script>';
}

// Si existe reseña
$existeResenaUsuario = $evento->existeResenaUsuario($_GET["id_evento"], $datosUsuario["ID_PERSONA"]);
if($existeResenaUsuario){
    echo '<script>alert("¡Ya has escrito una reseña!");</script>';
    echo '<script>window.location.href = "listar_resenas.php?id_perfil='.$consulta["ID_CREADOR"].'";</script>';
}
# --------------------------------------------------------------

// Mostrar datos
$consulta = $persona->mostrarPerfil($id_ceador);  // El modelo está importado por el controlador!
// Si no hay imagen, reemplazar por defecto
$imagenPersona = isset($consulta['IMAGEN_PERSONA']) ? "fotos_personas/". $consulta['IMAGEN_PERSONA'] : "img/favicon.png";

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">

    <style>
        .stars {
            display: inline-block;
            font-size: 30px;
            color: #888888;
            cursor: pointer;
        }

        .star-selected {
            color: #FFD700;
        }
    </style>

    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="title-single-box">
                        <h1 class="title-single">Formulario de reseñas</h1>
                        <span class="color-text-a">Comparte tu experiencia</span>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="inicio.php">Inicio</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Información del Usuario
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <!-- ======= Sección del perfil de usuario ======= -->
    <section class="agent-single">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row">

                        <!--/ Imagen de perfil /-->
                        <div class="col-md-6">
                            <div class="agent-avatar-box">
                                <img src="../assets/<?php echo $imagenPersona; ?>" alt="" class="agent-avatar img-fluid">
                            </div>
                        </div>

                        <?php
                        // Verificar si se ha enviado el formulario
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            // Obtener los valores enviados por el formulario
                                $comentario = $_POST["comentario"];
                                $puntuacion = $_POST["puntuacion"];
                        
                            // Validar la puntuación (debe ser un número entre 1 y 5)
                            if ($puntuacion < 1 || $puntuacion > 5) {
                                echo "<p>La puntuación debe ser un número entre 1 y 5.</p>";
                            } else {
                                if(isset($_POST['comentario']) and !empty(trim($_POST['comentario']))){
                                    $evento->ingresarResena($_POST, $datosUsuario["ID_PERSONA"]);
                                    echo '<script>alert("¡Muchas gracias por su reseña!");</script>';
                                    echo '<script>window.location.href = "listar_resenas.php?id_perfil='.$id_ceador.'";</script>';
                                }
                            }
                        }
                        ?>

                        <!--/ Formulario de reseña /-->
                        <form method="post" action="">
                            <label for="comentario">Comentario:</label><br>
                            <textarea name="comentario" rows="4" cols="50"></textarea><br><br>

                            <label for="puntuacion">Puntuación:</label><br>
                            <div class="stars">
                                <span class="star" onclick="setRating(1)">&#9734;</span>
                                <span class="star" onclick="setRating(2)">&#9734;</span>
                                <span class="star" onclick="setRating(3)">&#9734;</span>
                                <span class="star" onclick="setRating(4)">&#9734;</span>
                                <span class="star" onclick="setRating(5)">&#9734;</span>
                            </div>

                            <!--/ Guardar datos extra de la reseña /-->
                            <input type="hidden" name="puntuacion" id="puntuacion" value="0"><br><br>
                            <input type="hidden" name="id_evento" value="<?php echo isset($_GET['id_evento']) ? $_GET['id_evento'] : ''; ?>">

                            <div class="col-md-12">
                                <button type="submit" class="btn btn-b" value="Enviar" onclick="return confirm('Revise su reseña, luego no podrá borrarla. ¿Está seguro de enviarla?')">Subir reseña</button>
                            </div>
                        </form>

                        <script>
                             // Recorrer estrellas y marcar hasta la seleccionada
                            let stars = document.getElementsByClassName("star");
                            let ratingInput = document.getElementById("puntuacion");

                            function setRating(rating) {
                                ratingInput.value = rating;
                                for (let i = 0; i < stars.length; i++) {
                                    if (i < rating) {
                                        stars[i].classList.add("star-selected");
                                    } else {
                                        stars[i].classList.remove("star-selected");
                                    }
                                }
                            }
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/ FIN Sección del perfil de usuario /-->

    <!--
  ·····························································································
  ·····························································································
  -->

   
</main>

<?php include('modulos_compartidos/footer.php'); ?>