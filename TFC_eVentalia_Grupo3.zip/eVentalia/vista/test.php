<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Get the quantity value from the form
  $quantity = $_POST['quantity'];

  // Calculate the amounts for 80% and 20%
  $amount_1 = $quantity * 0.8;
  $amount_2 = $quantity * 0.2;

  // Prepare the data to be saved in the text file
  // $data = "80%: $amount80\r\n20%: $amount20\r\n";
  $data = "ID_USUARIO: correo@gmail.com\r\nTOTAL: {$quantity}€\r\n80% CREADOR: {$amount_1}€\r\n20% EVENTALIA: {$amount_2}€\r\r==================\r\r";

  // Specify the file path and name
  $file = '../LOGS/donaciones.txt';

  // Append the data to the file
  file_put_contents($file, $data, FILE_APPEND);

  // Output a success message
  echo "Distribution saved successfully!";
}
?>

<form method="post" action="">
  <label for="quantity">Quantity:</label>
  <input type="number" name="quantity" id="quantity" required>
  <button type="submit">Submit</button>
</form>