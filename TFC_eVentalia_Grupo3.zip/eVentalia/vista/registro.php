<?php
require('../controlador/controlador.php');
controlarVistas();

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');

if (isset($cuenta_OK) and !$cuenta_OK) {
    echo '<script>alert("¡Error al crear el usuario!");</script>';
    echo '<script>window.location.href = "registro.php";</script>';
}

$fechaMinima = new DateTime();
$fechaMinima->modify("-18 year");
$fechaMinima = date('Y-m-d', $fechaMinima->getTimestamp());
?>

<main id="main">
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="title-single-box">
                        <h1 class="title-single">Registrarse ahora</h1>
                        <span class="color-text-a">Registro Usuario</span>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="inicio.php">Inicio</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Registro usuario
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <!-- ======= Login Usuario ======= -->
    <section class="property-grid grid">
        <div class="container">
            <div class="row">
                <?php
                // Incluir formulario usuario
                $vista_ACTUAL = basename($_SERVER['PHP_SELF']);   // Obtener nombre de documento actual para identificar vista activa
                include('modulos_compartidos/MOD_formulario_usuario.php');
                ?>
            </div>
        </div>
    </section>
</main>

<?php include('modulos_compartidos/footer.php'); ?>