<!DOCTYPE html>
<html>
<head>
    <title>Identificación y Titularidad</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            font-size: 16px;
            margin: 40px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        h1, h2 {
            text-align: center;
        }

        h1 {
            margin-bottom: 30px;
        }

        p, ul {
            margin-bottom: 15px;
            font-size: 18px;
        }

        ul {
            padding-left: 20px;
        }
    </style>
</head>
<body>
    <h1>Identificación y Titularidad</h1>
    
    <h2>En cumplimiento del artículo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y Comercio Electrónico, el Titular expone sus datos identificativos:</h2>


<!DOCTYPE html>
<html>
<head>
    <title>Política de Privacidad - eVentalia</title>
</head>
<body>
    <h1>Política de Privacidad</h1>
    
    <h2>eventalia S.A. (en adelante, eVentalia) está especialmente sensibilizada en la protección de datos de carácter personal de los Usuarios de los servicios del sitio Web. Mediante la presente Política de Privacidad (o Política de Protección de Datos) eVentalia informa a los usuarios de los sitios web: http://www.eVentalia.com/, de los usos a los que se someten los datos de carácter personal que se recaban en el sitio web, con el fin de que decidan, libre y voluntariamente, si desean facilitar la información solicitada.</h2>

    <p>eVentalia se reserva la facultad de modificar esta Política con el objeto de adaptarla a novedades legislativas, criterios jurisprudenciales, prácticas del sector, o intereses de la entidad. Cualquier modificación en la misma será anunciada con la debida antelación, a fin de que tengas perfecto conocimiento de su contenido.</p>

    <h2>1. ¿Quién es el Responsable del tratamiento de sus datos personales?</h2>

    <p>El Responsable del Tratamiento de Datos es aquella persona física o jurídica, de naturaleza pública o privada, u órgano administrativo, que solo o conjuntamente con otros determine los fines y medios del tratamiento de datos personales. El Responsable del Tratamiento de los datos de carácter personal es:</p>

    <p>Titular: eVentalia S.A.</p>
    <p>Domicilio social a estos efectos en garaje de Rubén</p>
    <p>28034 - Madrid, España</p>
    <p>Tel.: 917777777</p>
    <p>E-mail: eVentalia@hotmail.com</p>

    <h2>2. ¿Para qué finalidades tratamos sus datos personales?</h2>

    <p>La finalidad de la recogida y tratamiento de los datos personales a través de la web de eVentalia responde a dar contestación a las consultas recibidas a través de los formularios de información u otras vías de comunicación establecidas en la web. Además, si lo desea, sus datos podrían utilizarse para la actividad de marketing y prospección comercial.</p>

    <h2>3. ¿Cuál es la base jurídica que legitima el tratamiento de sus datos personales?</h2>

    <p>eVentalia está legitimado al tratamiento de datos personales, en base al consentimiento otorgado por el interesado mediante la firma o aceptación de los pertinentes formularios, para uno o varios fines específicos, tal y como recoge el artículo 6.1. a del Reglamento General de Protección de Datos Personales.</p>

    <h2>4. ¿Por cuánto tiempo conservamos sus datos personales?</h2>

    <p>Los datos personales proporcionados se conservarán durante el plazo correspondiente para cumplir con las obligaciones legales, mientras no se oponga al tratamiento o revoque el consentimiento.</p>

    <h2>5. ¿Quiénes pueden ser cesionarios o destinatarios de tus datos personales?</h2>

    <p>Los datos personales no serán cedidos o comunicados a terceros, salvo en los supuestos necesarios para el desarrollo, control y cumplimiento de las finalidad/es expresada/s, y en los supuestos previstos según Ley.</p>

    <h2>6. ¿Cuáles son sus derechos en protección de datos y cómo puede ejercerlos?</h2>

    <p>El interesado de los datos personales podrá ejercitar los derechos que le asisten, de acuerdo con el Reglamento General de Protección de Datos, y que son:</p>

    <ul>
        <li>Derecho a solicitar el acceso a sus datos personales</li>
        <li>Derecho a solicitar su rectificación o supresión</li>
        <li>Derecho a solicitar la limitación de su tratamiento</li>
        <li>Derecho a oponerse al tratamiento</li>
        <li>Derecho a la portabilidad de los datos</li>
        <li>Derecho a retirar su consentimiento en cualquier momento</li>
    </ul>

    <p>El interesado podrá ejercitar tales derechos mediante solicitud acompañada de una fotocopia de su D.N.I o documento identificativo equivalente, y en la que especificará cuál de éstos solicita sea satisfecho, remitida a la dirección: Garaje de Rubén, CPP 28034, Madrid, España ; Email: eVentalia@hotmail.com.</p>

    <p>En caso de considerar vulnerado su derecho a la protección de datos personales, podrá interponer una reclamación ante la Agencia Española de Protección de Datos (www.aepd.es).</p>

    <h2>7. Exactitud de los datos</h2>

    <p>Por otro lado, con el fin de que los datos correspondan a la realidad, se tratará de mantenerlos actualizados, de manera que, a estos efectos, el Usuario deberá comunicarnos los cambios a Garaje de Rubén, CPP 28034, Madrid, España ; Email: eVentalia@hotmail.com.</p>

    <h2>8. Medidas de seguridad</h2>

    <p>eVentalia adoptará en su sistema de información las medidas técnicas y organizativas adecuadas, dando cumplimiento al principio de responsabilidad proactiva, a fin de garantizar la seguridad y confidencialidad de los datos almacenados, evitando así, su alteración, pérdida, tratamiento o acceso no autorizado; teniendo en cuenta el estado de la técnica, los costes de aplicación, y la naturaleza, el alcance, el contexto y los fines del tratamiento, así como riesgos de probabilidad y gravedad variables asociadas a cada uno de los tratamientos.</p>

    <p>Si tiene alguna pregunta sobre esta Política de Privacidad, rogamos que se ponga en contacto con nosotros enviando un email a eVentalia@hotmail.com.</p>
</body>
</html>

