<?php
require('../controlador/controlador.php');
controlarVistas();

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');


if (isset($datosUsuario) and !$datosUsuario) {
    echo '<script>alert("¡Error al iniciar sesión!");</script>';
    echo '<script>window.location.href = "login.php";</script>';
}
?>

<main id="main">
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="title-single-box">
                        <h1 class="title-single">Iniciar sesión</h1>
                        <span class="color-text-a">Login Usuario</span>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="inicio.php">Inicio</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Login Usuario
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <!-- ======= Login Usuario ======= -->
    <section class="property-grid grid">
        <div class="container">
            <div class="row">
                <form action="" method="post">

                    <!--/ Email usuario /-->
                    <div class="form-group mt-4">
                        <label for="email">*Email</label>
                        <input class="form-control" type="text" name="email" placeholder="Correo electrónico" required>
                    </div>

                    <!--/ Contraseña usuario /-->
                    <div class="form-group mt-4">
                        <label for="pass">*Contraseña</label>
                        <input class="form-control" type="password" name="pass" placeholder="Contraseña" required>
                    </div>
                    <br/>

                    <div class="col-md-12">
                        <button type="submit" class="btn btn-b" name="login_usuario">Iniciar sesión</button>
                    </div>

                    <?php if(isset($_GET['mensajeMail'])): ?>
                    <div class="col-md-12 mt-4 alert alert-warning">
                        <p><?= $_GET['mensajeMail'] ?? "" ?></p>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </section>
</main>

<?php include('modulos_compartidos/footer.php'); ?>