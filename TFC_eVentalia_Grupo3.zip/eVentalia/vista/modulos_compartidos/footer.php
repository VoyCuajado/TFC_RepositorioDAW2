<!--
  NOTAS:
    - En este documento se incluye el contenido del pie de página.
    - El contenido del pie de página es fluido y permite ampliaciones.
-->

<!-- ======= Footer ======= -->
<section class="section-footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-4">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand">Contáctanos</h3>
          </div>
          <div class="w-body-a">
            <p class="w-text-a color-text-a">
              ¡Tú opinion importa! No dudes en consultarnos cualquier duda y siéntete libre de enviarnos sugerencias.
            </p>
          </div>
          <div class="w-footer-a">
            <ul class="list-unstyled">
              <li class="color-a">
                <span class="color-text-a">Email .</span> eVentalia@hotmail.com
              </li>
              <li class="color-a">
                <span class="color-text-a">Teléfono .</span> +34 356 945 234
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-sm-12 col-md-4 section-md-t3">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand">Información</h3>
          </div>
          <div class="w-body-a">
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                  <i class="bi bi-chevron-right"></i> <a href="conocenos.php">Empresa</a>
                </li>
                <li class="item-list-a">
                  <i class="bi bi-chevron-right"></i> <a href="politica_privacidad.php">Documentación Legal</a>
                </li>
                <li class="item-list-a">
                  <i class="bi bi-chevron-right"></i> <a href="#">Administradores</a>
                </li>
                <li class="item-list-a">
                  <i class="bi bi-chevron-right"></i> <a href="#">Trabajadores</a>
                </li>
                <li class="item-list-a">
                  <i class="bi bi-chevron-right"></i> <a href="#">Afiliados</a>
                </li>
                <li class="item-list-a">
                  <i class="bi bi-chevron-right"></i> <a href="#">Políticas de privacidad</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-12 col-md-4 section-md-t3">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand">Colaboradores</h3>
          </div>
          <div class="w-body-a">
            <ul class="list-unstyled">
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="https://www.nike.com/es/">Nike</a>
              </li>
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="https://www.adidas.es/">Addidas</a>
              </li>
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="https://ronbarcelo.com/en/">Ron Barceló</a>
              </li>
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="https://www.comunidad.madrid/">CCMM</a>
              </li>
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="https://www.madrid.es/portal/site/munimadrid">Ayuntamiento de Madrid</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <nav class="nav-footer">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="#">Volver arriba</a>
            </li>
          </ul>
        </nav>
        <div class="socials-a">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="https://www.facebook.com/">
                <i class="bi bi-facebook" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="https://www.twitter.com/">
                <i class="bi bi-twitter" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="https://www.instagram.com/">
                <i class="bi bi-instagram" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="https://www.linkedin.com/">
                <i class="bi bi-linkedin" aria-hidden="true"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="copyright-footer">
          <p class="copyright color-text-a">
            &copy; Copyright <span class="color-a">eVentalia</span> All Rights Reserved.
          </p>
        </div>
      </div>
    </div>
  </div>
</footer><!-- FIN  Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- JavaScript complementario -->
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="../assets/vendor/php-email-form/validate.js"></script>

<!-- JavaScript principal -->
<script src="../assets/js/main.js"></script>

</body>
</html>