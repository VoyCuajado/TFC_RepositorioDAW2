<?php
require('../controlador/controlador.php');
controlarVistas();

if (isset($_POST["editar_usuario"])) {
    $edicion_OK = $persona->modificarUsuario($_POST, $_FILES["foto"], $datosUsuario["ID_PERSONA"]);

    // Mostrar popup de estado
    if ($edicion_OK) {
        echo '<script>alert("Se ha editado el perfil");</script>';
    }
    else {
        echo '<script>alert("Error al editar el perfil. Ninguno de los campos ha sido afectado");</script>';
    }
}

// >> BORRAR CUENTA
if (isset($_POST["borrar_usuario"])) {
    include('../modelo/evento.php');
    $evento = new Evento();

    $consulta = $evento->todosEventosUsuario($datosUsuario["ID_PERSONA"]);
    foreach ($consulta as $key => $fila) {
        $evento->borrarImagen($fila["IMAGEN_EVENTO"]);
    }
    
    $persona->borrarUsuario($datosUsuario["ID_PERSONA"]);

    setcookie(
        "datosUsuario",
        "",
        time() - 3600
    );
    echo '<script>window.location.href = "inicio.php";</script>';
}

$consulta = $persona->mostrarPerfil($datosUsuario["ID_PERSONA"]);

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="title-single-box">
                        <h1 class="title-single">Editar perfil</h1>
                        <span class="color-text-a">Edición Perfil Usuario</span>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="inicio.php">Inicio</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Edición Perfil Usuario
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!--/ Botón para volver /-->
        <br/>
        <div class="container">
            <form action="perfil_usuario.php?pag=1" method="post">
                <button type="submit" class="btn btn-b">Volver a Mi perfil</button>
            </form>
        </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <!-- ======= Modificar Usuario ======= -->
    <?php
    // Incluir formulario usuario
    $vista_ACTUAL = basename($_SERVER['PHP_SELF']);   // Obtener nombre de documento actual para identificar vista activa
    include('modulos_compartidos/MOD_formulario_usuario.php');
    ?>
</main>

<?php include('modulos_compartidos/footer.php'); ?>