<?php
require('../controlador/controlador.php');

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<!-- ======= Intro Section ======= -->
<div class="intro intro-carousel swiper position-relative">
  <div class="swiper-wrapper">
    <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(../assets/img/inicio-slide-1.jpg)">
      <div class="overlay overlay-a"></div>
      <div class="intro-content display-table">
        <div class="table-cell">
          <div class="container">
            <div class="row">
              <div class="col-lg-8">
                <div class="intro-body">
                  <h1 class="intro-title mb-4 ">
                    <span class="color-b">CREA</span>
                    <br>Tus eventos
                  </h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(../assets/img/inicio-slide-2.jpg)">
      <div class="overlay overlay-a"></div>
      <div class="intro-content display-table">
        <div class="table-cell">
          <div class="container">
            <div class="row">
              <div class="col-lg-8">
                <div class="intro-body">
                  <h1 class="intro-title mb-4">
                    <span class="color-b">SOCIALIZA</span>
                    <br>Con gente de toda España
                  </h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(../assets/img/inicio-slide-3.jpg)">
      <div class="overlay overlay-a"></div>
      <div class="intro-content display-table">
        <div class="table-cell">
          <div class="container">
            <div class="row">
              <div class="col-lg-8">
                <div class="intro-body">
                  <h1 class="intro-title mb-4">
                    <span class="color-b">DISFRUTA</span>
                    <br>De momentos inolvidables
                  </h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- <div class="swiper-pagination"></div> -->
</div><!-- End Intro Section -->

<!--
·····························································································
·····························································································
-->

<main id="main">
  <!-- ======= Cómo empezar ======= -->
  <section class="section-services section-t8">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a">Cómo empezar</h2>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="card-box-c foo">
            <div class="card-header-c d-flex">
              <div class="card-box-ico">
                <span class="bi bi-chat-text"></span>
              </div>
              <div class="card-title-c align-self-center">
                <h2 class="title-c">Socializar</h2>
              </div>
            </div>
            <div class="card-body-c">
              <p class="content-c">
                Busca y relaciónate con otros usuarios de eVentalia. ¡La mejora forma de conocerse es probando cosas nuevas!
              </p>
            </div>
            <div class="card-footer-c">
              <a href="#" class="link-c link-icon">Aprende más
                <span class="bi bi-chevron-right"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box-c foo">
            <div class="card-header-c d-flex">
              <div class="card-box-ico">
                <span class="bi bi-calendar4-week"></span>
              </div>
              <div class="card-title-c align-self-center">
                <h2 class="title-c">Organizar</h2>
              </div>
            </div>
            <div class="card-body-c">
              <p class="content-c">
                Organiza y ten control de tus propios eventos. Todos los eventos son creados por la comunidad. ¡Respeta las normas y a otros usuarios!
              </p>
            </div>
            <div class="card-footer-c">
              <a href="#" class="link-c link-icon">Aprende más
                <span class="bi bi-calendar4-week"></span>
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box-c foo">
            <div class="card-header-c d-flex">
              <div class="card-box-ico">
                <span class="bi bi-card-checklist"></span>
              </div>
              <div class="card-title-c align-self-center">
                <h2 class="title-c">Gestionar</h2>
              </div>
            </div>
            <div class="card-body-c">
              <p class="content-c">
                Los eventos que hayas creado se pueden editar en cualquier momento desde tu perfil. Solo tú podras cambiar los detalles del evento.
              </p>
            </div>
            <div class="card-footer-c">
              <a href="#" class="link-c link-icon">Aprende más
                <span class="bi bi-chevron-right"></span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- FIN Cómo empezar -->

  <!--
  ·····························································································
  ·····························································································
  -->

  <!-- ======= Eventos más recientes ======= -->
  <?php
  include('../modelo/evento.php');
  $evento = new Evento();
  $consulta = $evento->ultimosEventos();
  ?>

  <section class="section-property section-t8">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a">Eventos más recientes</h2>
            </div>
            <div class="title-link">
              <a href="ver_eventos.php?pag=1">Todos los eventos
                <span class="bi bi-chevron-right"></span>
              </a>
            </div>
          </div>
        </div>
      </div>

      <div id="property-carousel" class="swiper">
        <div class="swiper-wrapper">

        <?php foreach ($consulta as $key => $fila) :
        // Si no hay imagen, reemplazar por defecto
        $imagenEvento = isset($fila['IMAGEN_EVENTO']) ? "fotos_eventos/". $fila['IMAGEN_EVENTO'] : "img/property-1.jpg";
        ?>
        <div class="carousel-item-b swiper-slide">
          <div class="card-box-a card-shadow">
            <div class="img-box-a">
              <img src="../assets/<?php echo $imagenEvento; ?>" style="min-height: 500px; max-width: 500px; height: auto;" alt="" class="img-a img-fluid">
            </div>
            <div class="card-overlay">
              <div class="card-overlay-a-content">

                <!--/ Nombre del evento /-->
                <div class="card-header-a">
                  <h2 class="card-title-a">
                    <a href="#"><?php echo $fila['NOMBRE']; ?></a>
                  </h2>
                </div>

                <!--/ Lugar del evento /-->
                <div class="card-body-a">
                  <div class="price-box d-flex">
                    <span class="price-a"><?php echo $fila['NOMBRE_PROVINCIA']; ?></span>
                  </div>
                  <a href="pagina_evento.php?id_evento=<?php echo $fila['ID_EVENTO']; ?>" class="link-a">Haz click para ver
                    <span class="bi bi-chevron-right"></span>
                  </a>
                </div>

                <!--/ Info del evento /-->
                <div class="card-footer-a">
                  <ul class="card-info d-flex justify-content-around">
                    <li>
                      <h4 class="card-info-title">Categoría</h4>
                      <span><?php echo $fila['CATEGORIA']; ?></span>
                    </li>
                    <li>
                      <h4 class="card-info-title">Fecha</h4>
                      <span><?php echo $fila['FECHA_HORA']; ?></span>
                    </li>
                    <li>
                      <h4 class="card-info-title">Aforo</h4>
                      <span><?php echo $fila['AFORO'] ?></span>
                    </li>
                  </ul>
                </div>

              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?><!--/ FIN Impresión de últimos eventos /-->

        </div>
      </div>
      <div class="propery-carousel-pagination carousel-pagination"></div>

    </div>
  </section><!-- FIN Eventos más recientes -->

</main><!-- End #main -->

<?php include('modulos_compartidos/footer.php'); ?>