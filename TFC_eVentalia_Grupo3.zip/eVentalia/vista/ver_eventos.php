<?php
require('../controlador/controlador.php');
controlarVistas();

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">
  <!-- ======= Título/Breadcrumbs ======= -->
  <section class="intro-single">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-8">
          <div class="title-single-box">
            <h1 class="title-single">Ver eventos</h1>
            <span class="color-text-a">Listado Eventos</span>
          </div>
        </div>
        <div class="col-md-12 col-lg-4">
          <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="inicio.php">Inicio</a>
              </li>
              <li class="breadcrumb-item active" aria-current="page">
                Listado Eventos
              </li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section><!-- FIN Título/Breadcrumbs -->

  <!--
  ·····························································································
  ·····························································································
  -->

  <?php
  include('../modelo/evento.php');
  $evento = new Evento();
  $consulta = $evento->buscarEvento($_GET, $pag_actual, $total_pag, false, true);  // "pag_actual" y "$total_pag" se devuelven de la conuslta y no hace falta declararlas de antemano

  // Incluir listado eventos
  $vista_ACTUAL = basename($_SERVER['PHP_SELF']);   // Obtener nombre de documento actual para identificar vista activa
  include('modulos_compartidos/MOD_listado_eventos.php');
  ?>
</main>

<?php include('modulos_compartidos/footer.php'); ?>