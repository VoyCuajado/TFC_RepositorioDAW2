<?php
require('../controlador/controlador.php');
controlarVistas();

if (isset($_GET['id_creador'])) {
  $idCreador = $_GET['id_creador'];
  $consulta = $persona->mostrarPerfil($idCreador);
  $id_persona = $consulta ? $consulta['ID_PERSONA'] : "";
} else {
  // Transformar valores de URL en array
  $queryString = $_SERVER['QUERY_STRING'];
  $queryValues = array();
  parse_str($_SERVER['QUERY_STRING'], $queryValues);

  $id_persona = isset($queryValues["id_persona"]) ? $queryValues["id_persona"] : $datosUsuario["ID_PERSONA"];

  // Mostrar perfil de persona 
  $consulta = $persona->mostrarPerfil($id_persona);  // El modelo está importado por el controlador!
}

// Formatear fecha
if ($consulta) {
  $fechaNacimiento = strtotime($consulta['FECHA_NACIMIENTO']);
  $fechaFormateada = date('d/m/Y', $fechaNacimiento);
}

// Si no hay imagen, reemplazar por defecto
$imagenPersona = isset($consulta['IMAGEN_PERSONA']) ? "fotos_personas/" . $consulta['IMAGEN_PERSONA'] : "img/favicon.png";

include('../modelo/evento.php');
$evento = new Evento(); // Inicializamos el objeto evento para poder mostrar las reseñas.
$puntuacion = $evento->calcularMediaPuntuacion($id_persona); 
$cantidadComentarios = count($evento->mostrarResena($id_persona));

include('modulos_compartidos/metadata.php');
include('modulos_compartidos/header.php');
?>

<main id="main">

  <?php if ($consulta) : // Si existe el usuario ?>
  <!-- ======= Título/Breadcrumbs ======= -->
  <section class="intro-single">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-8">
          <div class="title-single-box">
            <h1 class="title-single">Perfil del Usuario</h1>
            <span class="color-text-a">Información del Usuario</span>
          </div>
        </div>
        <div class="col-md-12 col-lg-4">
          <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="inicio.php">Inicio</a>
              </li>
              <li class="breadcrumb-item active" aria-current="page">
                Información del Usuario
              </li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section><!-- FIN Título/Breadcrumbs -->

  <!-- ======= Sección del perfil de usuario ======= -->
  <section class="agent-single">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="row">
            <!--/ Imagen de perfil /-->
            <div class="col-md-6">
              <div class="agent-avatar-box">
                <img src="../assets/<?php echo $imagenPersona; ?>" alt="" class="agent-avatar img-fluid">
              </div>
            </div>
            <!--/ Datos de usuario /-->
            <div class="col-md-5 section-md-t3">
              <div class="agent-info-box">
                <!--/ Nombre de usuario /-->
                <div class="agent-title">
                  <div class="title-box-d">
                    <h3 class="title-d">
                      <?php echo $consulta['NOMBRE'] . " " . $consulta['APELLIDOS']; ?>
                    </h3>
                  </div>
                </div>
                <!--/ Descripcción y datos de usuario /-->
                <div class="agent-content mb-3">
                  <p class="content-d color-text-a">
                    <?php echo $consulta["DESCRIPCION"]; ?>
                  </p>
                  <div class="info-agents color-a">
                    <p><strong>Nombre: </strong><span class="color-text-a"><?php echo $consulta['NOMBRE']; ?></span></p>
                    <p><strong>Apellidos: </strong><span class="color-text-a"><?php echo $consulta['APELLIDOS']; ?></span></p>
                    <p><strong>Correo electrónico: </strong><span class="color-text-a"><?php echo $consulta['EMAIL']; ?></span></p>
                    <p><strong>Dirección: </strong><span class="color-text-a"><?php echo $consulta['DIRECCION']; ?></span></p>
                    <p><strong>Teléfono: </strong><span class="color-text-a"><?php echo $consulta['TELEFONO']; ?></span></p>
                    <p><strong>Fecha nacimiento: </strong><span class="color-text-a"><?php echo $fechaFormateada; ?></span></p>
                  </div>
                  <!--/ Resumen reseñas de usuario /-->
                  <div class="reseñas-link">
                    <p>
                      <strong>Reseñas:</strong>
                      <!--/ Cálculo de estrellas /-->
                      <?php 
                      if ($puntuacion > 0) :
                        for ($i = 0; $i < $puntuacion; $i++) :
                      ?>
                      <i class="bi bi-star-fill text-warning"></i>
                      <?php
                        endfor;
                      endif;
                      ?>
                      <!--/ Cálculo de puntuación /-->
                      <?php echo " ". $puntuacion ."/5 - ".$cantidadComentarios." opiniones" ?>
                    </p>
                    <a href="./listar_resenas.php?id_perfil=<?php echo $id_persona; ?>"><strong><span class="bi bi-chevron-right">Ver reseñas</span></strong></a>
                  </div>
                </div>
              </div>
              <!--/ Iconos redes sociales /-->
              <div class="socials-footer">
                <ul class="list-inline">
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="bi bi-facebook" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="bi bi-twitter" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="bi bi-instagram" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="bi bi-linkedin" aria-hidden="true"></i>
                    </a>
                  </li>
                </ul>
              </div>
              <!--/ Editar perfil /-->
              <?php if ($id_persona == $datosUsuario["ID_PERSONA"]) : ?>
              <form action="editar_usuario.php" method="POST">
                <button type="submit" class="btn btn-b"><i class="bi bi-pencil-square"></i> Editar Mi perfil</button>
              </form>
              <br/>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!--/ FIN Sección del perfil de usuario /-->

  <?php else : // En caso de no existir el usuario ?>
    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">¿Y el perfil?</h1>
              <span class="color-text-a">¡Parece que ha habido un error!<br />Inténtalo de nuevo más tarde<br /></span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="inicio.php">Inicio</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Información del Usuario
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- FIN Título/Breadcrumbs -->
  <?php endif; ?>

  <!--
  ·····························································································
  ·····························································································
  -->

  <?php if ($id_persona == $datosUsuario["ID_PERSONA"]) : ?>

    <!-- ======= Título/Breadcrumbs ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">Mis eventos</h1>
              <span class="color-text-a">Listado Mis Eventos</span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="inicio.php">Inicio</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Listado Mis Eventos
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- FIN Título/Breadcrumbs -->

    <?php
    $consulta = $evento->buscarEvento($_GET, $pag_actual, $total_pag, $id_persona);  // "pag_actual" y "$total_pag" se devuelven de la conuslta y no hace falta declararlas de antemano

    // Incluir listado eventos (usuario)
    $vista_ACTUAL = basename($_SERVER['PHP_SELF']);   // Obtener nombre de documento actual para identificar vista activa
    include('modulos_compartidos/MOD_listado_eventos.php');
    ?>
    <?php endif; ?>
</main>

<?php include('modulos_compartidos/footer.php'); ?>