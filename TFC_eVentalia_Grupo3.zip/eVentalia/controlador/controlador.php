<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require_once __DIR__."/../librerias/PHPMailer/src/PHPMailer.php";
    require_once __DIR__."/../librerias/PHPMailer/src/SMTP.php";
    require_once __DIR__."/../librerias/PHPMailer/src/Exception.php";
/*
    NOTAS:
        - Las sesiones se controlan mediante la COOKIE "datosUsuario"
        - En caso de no haber sesión se redirige a "inicio.php"
        - SIEMPRE llamar "controlarVistas()" en vistas que requieran sesión

            Ejemplo.:
            ------------------------------------------
            require('../controlador/controlador.php');
            controlarVistas();
            ------------------------------------------
*/

/*
·····························································································
·····························································································
*/


include("../modelo/persona.php");
$persona = new Persona();

// >> CONTROLAR ACCESO SIN LOGIN
function controlarVistas() {
    // Comprobación de sesión en vista "login" y "registro"
    if (basename($_SERVER['PHP_SELF']) == "login.php" or basename($_SERVER['PHP_SELF']) == "registro.php") {
        isset($_COOKIE['datosUsuario']) ? header("Location: ./inicio.php") : false;
    }
    // Redirigir en vistas que requieran sesión
    else if (!isset($_COOKIE['datosUsuario'])) {
        header("Location: ./inicio.php");
    }
}

// >> RECUPERAR DATOS SERIALIZADOS DE SESIÓN
if (isset($_COOKIE["datosUsuario"])) {
    $datosUsuario = unserialize($_COOKIE["datosUsuario"]);  // Recuperar datos del usuario
    $datosUsuario = array (
        "ID_PERSONA" => $datosUsuario[0]
    );
}

// >> CREAR CUENTA
if (isset($_POST['registrar_usuario'])) {
    $cuenta_OK = $persona->registrarUsuario($_POST, $_FILES['foto']);
    if ($cuenta_OK) {
        enviarMail();   // Llamamos a la función para que se envie email de bienvenida al correo registrado.
        header("Location: ./login.php?mensajeMail=Se ha registrado correctamente. En breve recibirá en su correo electrónico su confirmación");
    }
}

// >> INICIAR SESIÓN USUARIO
if (isset($_POST['login_usuario'])) {
    $datosUsuario = $persona->loginUsuario($_POST);

    if ($datosUsuario) {
        // Preparar datos de COOKIE
        $arrayDatos = array(
            $datosUsuario["ID_PERSONA"]
        );
        $arrayDatos = serialize($arrayDatos);   // Serializa el array para guardar los datos en la misma cookie

        // Guardar datos serializados en COOKIE
        setcookie(
            "datosUsuario",
            $arrayDatos,
            time() + (30 * 24 * 60 * 60)    // Guardar usuario por 30 días
        );
        header("Location: ./inicio.php");   
    }
}

// >> CERRAR SESIÓN USUARIO
if (isset($_GET['cerrar_sesion'])) {
    setcookie(
        "datosUsuario",
        "",
        time() - 3600
    );
    header("Location: ./inicio.php");
}


// >> Funciones MAILER
// >> FUNCIÓN ENVIAR CORREO BIENVENIDA AL REGISTRARSE
function enviarMail(){
    
    //Crear una instancia; Pasar 'true' habilita excepciones
    $mail = new PHPMailer(true);
    
    try {
        //Configuración del servidor (server settings) isSMTP--> Simple Mail Transfer Protocol
        //Indica que el envío de correo se realizará utilizando un servidor SMTP. 
        //Esta configuración es necesaria para establecer la conexión con el servidor SMTP y enviar el correo electrónico a través de él.
        $mail->isSMTP();
        $mail->Host = 'sandbox.smtp.mailtrap.io';
        $mail->SMTPAuth = true;
        $mail->Port = 2525;
        $mail->Username = '3c48724fc7ea02';
        $mail->Password = '10b11673b9da62'; 
        $mail->SMTPSecure = 'tls';   
        
        // Servidor de pago spark
        // $mail->isSMTP();
        // $mail->Host = 'smtp.sparkpostmail.com';
        // $mail->SMTPAuth = true;
        // $mail->Port = 587;
        // $mail->Username = 'SMTP_Injection';
        // $mail->Password = 'df4d5f302648c7d4e44792507ea6acc6ff7c684a'; // Hemos creado una contraseña (mailer en sparkpost) y ese es el hashcode
        // $mail->SMTPSecure = 'tls'; 
        // $mail->SMTPDebug = 3;
        
        //Destinatarios --> Recipients
        $mail->setFrom('eventalia@eventalia.com', 'eVentalia');
        $mail->addAddress('jorgesmaceda@hotmail.com', 'YO');     //Añadir destinatarios --> Add a recipient
        // $mail->addCC('cc@example.com'); // Copia
        // $mail->addBCC('bcc@example.com'); // Copia oculta, por ejemplo, podria servir para el usuario admin para que te des por enterado de que tienes un nuevo suscriptor
    
        //Contenido del correo
        $mail->isHTML(true);                                  //Configurar email en formato HTML
        $mail->Subject = 'Bienvenido a eVentalia';
        $mail->Body    = '<b>Bienvenido a eVentalia, ahora eres parte de nuestra gran familia</b>';
    
        $mail->send();
    } catch (Exception $e) {
        echo "Mensaje no pudo ser enviado. Mailer Error: {$mail->ErrorInfo}";
    }
}


// >> INICIAR DONACIÓN A CREADOR DE EVENTO
if (isset($_POST["donar"])) {
    if (isset($_POST['cantidad']) and $_POST['cantidad']>0) {
    enviarMailDonar($_POST["idEvento"], $_POST["email"], $_POST["cantidad"], $_POST["titular"], $_POST["tarjeta"]);
    }
}

// >> FUNCIÓN ENVIAR CORREO Agradecimiento donación
function enviarMailDonar($idEvento, $email, $cantidad, $titular, $tarjeta){
    
    //Crear una instancia; Pasar 'true' habilita excepciones
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = 'sandbox.smtp.mailtrap.io';
        $mail->SMTPAuth = true;
        $mail->Port = 2525;
        $mail->Username = '3c48724fc7ea02';
        $mail->Password = '10b11673b9da62'; 
        $mail->SMTPSecure = 'tls';   
                
        //Destinatarios --> Recipients
        $mail->setFrom('eventalia@eventalia.com', 'eVentalia');
        $mail->addAddress($email, $titular);      
        //Contenido del correo
        $mail->isHTML(true);                                 
        $mail->Subject = 'Gracias por donar';
        $mail->Body    = '<b>&#33;Has donado'.$cantidad.'&#8364;! Se cobrar&aacute; a la tarjeta: '.$tarjeta.'. </b>';
    
        $mail->send();
        echo '<script>alert("¡Muchas gracias por tu donación eres el mejor!");</script>';
        echo '<script>window.location.href = "pagina_evento.php?id_evento='.$idEvento.';</script>';
        // header("location: pagina_evento.php?id_evento=".$idEvento);
        
    } catch (Exception $e) {
        // echo "Mensaje no puedo ser enviado. Mailer Error: {$mail->ErrorInfo}";
    }
}

?>