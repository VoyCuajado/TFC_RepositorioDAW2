<?php

require_once("conexion.php");

class Persona extends Conexion {
    private $conn = null;

    public function __construct() {
        $this->conn = parent::conexion();
    }


    // PERFIL DE UN USUARIO
    public function mostrarPerfil($id_persona) {
        try {
            $sql = "SELECT * FROM personas WHERE ID_PERSONA = :ID_PERSONA";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_PERSONA", $id_persona);
            $stmt->execute();
            $registros = $stmt->fetch();
    
            return $registros;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // OBTENER TODAS LAS SUBCSRIPCIONES DE UN USUARIO
    public function mostrarSubscripciones($id_persona) {
        try {
            $sql = "SELECT * FROM subscripciones WHERE ID_PERSONA = :ID_PERSONA";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_PERSONA", $id_persona);
            $stmt->execute();
            $registros = $stmt->fetchALL(PDO::FETCH_ASSOC);
    
            return $registros;
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        } 
    }

    // >> GUARDAR IMAGEN EN PERSONA
    private function guardarImagen($datosImagen, $id_persona=false) {
        try {
            $nombreImagen = "";     // En caso de no haber imagen se inserta vacio

            if (strlen($datosImagen['name'][0]) > 0) {
                // Datos de la imagen
                $nombreImagen = time(). $datosImagen['name'][0]; // Concatenar tiempo actual para evitar nombres duplicados
                $imagenTmpPath = $datosImagen['tmp_name'][0];

                // Subir imagen al directorio
                $destino = '../assets/fotos_personas/'. $nombreImagen;
                move_uploaded_file($imagenTmpPath, $destino);
            }

            if ($id_persona) {
                $sql = "UPDATE personas SET IMAGEN_PERSONA = :IMAGEN_PERSONA WHERE ID_PERSONA = :ID_PERSONA";
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue("IMAGEN_PERSONA", $nombreImagen);
                $stmt->bindValue("ID_PERSONA", $id_persona);
                $stmt->execute();
            }
            else {
                $ultimo_id = $this->conn->lastInsertId();

                $sql = "UPDATE personas SET IMAGEN_PERSONA = :IMAGEN_PERSONA WHERE ID_PERSONA = :ID_PERSONA";
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue("IMAGEN_PERSONA", $nombreImagen);
                $stmt->bindValue("ID_PERSONA", $ultimo_id);
                $stmt->execute();
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> BORRAR IMAGEN (eliminar del directorio y BD)
    private function borrarImagen($nombreImagen) {
        try {
            // Borrar archivo del directorio de imágenes
            if ($nombreImagen) {
                $rutaImagen = '../assets/fotos_personas/'. $nombreImagen;   // Ruta imagen
                file_exists($rutaImagen) ? unlink($rutaImagen) : false;     // Borrar imagen
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> INICIAR SESIÓN USUARIO
    public function loginUsuario($params) {
        try {
            $sql = "SELECT * FROM personas WHERE email = :email";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":email", $params['email']);
            $stmt->execute();
            $datosUsuario = $stmt->fetch();

            if (!empty($datosUsuario)) {
                if (password_verify($params['pass'], $datosUsuario['PASSWORD']) and $datosUsuario["EMAIL"] == $params["email"]) {
                    return $datosUsuario;
                }
                else {
                    return false;
                }
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // >> REGISTRAR USUARIO EN BD
    public function registrarUsuario($params, $files) {
        try {
            // Validar edad
            $edad = new DateTime($params["nacimiento"]);
            $fecha_actual = new DateTime();
            $edad_OK = $fecha_actual->diff($edad)->y > 18 ? true : false;

            // Validar email
            $email_OK = preg_match("/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/", $params["email"]);
            $email_sanitizado = filter_var($params["email"], FILTER_VALIDATE_EMAIL);
            
            $sql = "SELECT EMAIL FROM personas WHERE EMAIL = :EMAIL";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":EMAIL", $email_sanitizado);
            $stmt->execute();
            if ($stmt->fetch()) {
                $email_OK = false;
            }

            // Validad teléfono
            $telefono_OK = preg_match("/[0-9]{9}/", $params["telefono"]);

            // Validar contraseña
            $pass_OK = false;
            if ($params["pass_1"] == $params["pass_2"]) {
                $passCifrada = password_hash($params["pass_1"], PASSWORD_DEFAULT);
                $pass_OK = true;
            }
               
            if ($edad_OK and $email_OK and $email_sanitizado and $pass_OK and $telefono_OK) {
                $sql = "INSERT INTO PERSONAS (NOMBRE, APELLIDOS, EMAIL, PASSWORD, DIRECCION, TELEFONO, FECHA_NACIMIENTO, DESCRIPCION)
                VALUES (:NOMBRE, :APELLIDOS, :EMAIL, :PASSWORD, :DIRECCION, :TELEFONO, :FECHA_NACIMIENTO, :DESCRIPCION)";

                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(":NOMBRE", $params['nombre']);
                $stmt->bindValue(":APELLIDOS", $params['apellidos']);
                $stmt->bindValue(":EMAIL", $params['email']);
                $stmt->bindValue(":PASSWORD", $passCifrada);
                $stmt->bindValue(":DIRECCION", $params['direccion']);
                $stmt->bindValue(":TELEFONO", $params['telefono']);
                $stmt->bindValue(":FECHA_NACIMIENTO", $params['nacimiento']);
                $stmt->bindValue(":DESCRIPCION", $params["descripcion"]);
                $stmt->execute();
    
                // Comprobar si hay imagen antes de insertar
                if (strlen($files['name'][0]) > 0) {
                    $this->guardarImagen($files);
                }

                return true;
            }
            else {
                return false;
            }
        }
        catch (PDOException $e) {
            // echo $e->getMessage();
            return false;
        }
    }

    // >> EDITAR USUARIO
    public function modificarUsuario($params, $files, $id_usuario) {
        try {
            // Validad teléfono
            $telefono_OK = preg_match("/[0-9]{9}/", $params["telefono"]);

            // Validar contraseña
            $passCifrada = $this->mostrarPerfil($id_usuario)["PASSWORD"];
            $pass_OK = true;

            if (isset($params["pass_1"]) and isset($params["pass_2"])) {
                if (!empty($params["pass_1"]) and !empty($params["pass_2"])) {
                    $pass_OK = password_verify($params["pass_1"], $passCifrada);

                    if (password_verify($params["pass_1"], $passCifrada)) {
                        $passCifrada = password_hash($params["pass_2"], PASSWORD_DEFAULT);
                        $pass_OK = true;
                    }
                    else {
                        $pass_OK = false;
                    }
                }
            }

            if ($telefono_OK and $pass_OK) {
                if (strlen($files['name'][0]) > 0) {
                    // Recuperar nombre de imagen (si hay)
                    $sql = "SELECT IMAGEN_PERSONA FROM personas WHERE ID_PERSONA = :ID_PERSONA";
                    $stmt = $this->conn->prepare($sql);
                    $stmt->bindValue(':ID_PERSONA', $id_usuario);
                    $stmt->execute();
    
                    // Actualizar imagen
                    $nombreImagen = $stmt->fetch()["IMAGEN_PERSONA"];
                    $this->borrarImagen($nombreImagen);
                    $this->guardarImagen($files, $id_usuario);
                }
                
                $sql = "UPDATE personas SET
                    NOMBRE = :NOMBRE,
                    APELLIDOS = :APELLIDOS,
                    PASSWORD = :PASSWORD,
                    DIRECCION = :DIRECCION,
                    TELEFONO = :TELEFONO,
                    DESCRIPCION = :DESCRIPCION
                WHERE ID_PERSONA = :ID_PERSONA";
    
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(":NOMBRE", $params["nombre"]);
                $stmt->bindValue(":APELLIDOS", $params["apellidos"]);
                $stmt->bindValue(":PASSWORD", $passCifrada);
                $stmt->bindValue(":DIRECCION", $params["direccion"]);
                $stmt->bindValue(":TELEFONO", $params["telefono"]);
                $stmt->bindValue(":DESCRIPCION", $params["descripcion"]);
                $stmt->bindValue(":ID_PERSONA", $id_usuario);
                $stmt->execute();
    
                return true;
            }
        }
        catch (PDOException $e) {
            // echo $e->getMessage();
            return false;
        }
    }

    // >> BORRAR USUARIO (elimina todos sus eventos!)
    public function borrarUsuario($id_usuario) {
        try{
            $sql = "SELECT IMAGEN_PERSONA FROM personas WHERE ID_PERSONA = :ID_PERSONA";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_PERSONA", $id_usuario);
            $stmt->execute();
            
            // Borrar imagen de perfil
            $nombreImagen = $stmt->fetch()["IMAGEN_PERSONA"];
            $this->borrarImagen($nombreImagen);

            $sql = "DELETE FROM personas WHERE ID_PERSONA = :ID_PERSONA";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(":ID_PERSONA", $id_usuario);     // Revisar este campo en formulario!!!
            $stmt->execute();
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}

?>