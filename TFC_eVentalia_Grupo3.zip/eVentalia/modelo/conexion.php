<?php

class Conexion {
    private $DB ="eventalia_2", $user ="root", $pass ="", $servidor ="localhost", $tabla;
   
    public function __construct($tabla) {
        $this->tabla = $tabla;
    }

    public function conexion(){
        try {
            $conn = new PDO("mysql:host=$this->servidor;dbname=$this->DB", $this->user, $this->pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        }
        catch(PDOException $e){
            die("Error:". $e->getMessage());
        }
    }
}

?>